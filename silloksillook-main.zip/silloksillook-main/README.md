# 실록실룩 소개
국사편찬위원회 조선왕조실록 DB 기사를 수집할 수 있는 도구입니다.

# 개발 현황
아직 개발 중입니다.

# 실행하기 (Linux)
```bash
$ python3 -m venv ./venv

$ chmod +x ./venv/bin/activate

$ ./venv/bin/activate

$ pip install -r requirements.txt

$ python3 ./main.py
```
