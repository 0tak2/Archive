#!/bin/sh

chmod +x ./venv/bin/activate
./venv/bin/activate
python3 ./main.py