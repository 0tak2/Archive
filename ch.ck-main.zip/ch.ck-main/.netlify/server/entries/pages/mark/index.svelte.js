var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var stdin_exports = {};
__export(stdin_exports, {
  default: () => Mark
});
module.exports = __toCommonJS(stdin_exports);
var import_index_58de3ccc = require("../../../chunks/index-58de3ccc.js");
var index_svelte_svelte_type_style_lang = /* @__PURE__ */ (() => "main.svelte-mdfsuy{text-align:center;margin-bottom:15rem}h1.svelte-mdfsuy{width:100%}")();
const css = {
  code: "main.svelte-mdfsuy{text-align:center;margin-bottom:15rem}h1.svelte-mdfsuy{width:100%}",
  map: null
};
const Mark = (0, import_index_58de3ccc.c)(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `${$$result.head += `${$$result.title = `<title>\uBE44\uC815\uC0C1\uC801\uC778 \uC811\uADFC</title>`, ""}`, ""}

<main class="${"svelte-mdfsuy"}"><h1 class="${"svelte-mdfsuy"}">\uBE44\uC815\uC0C1\uC801\uC778 \uC811\uADFC
	</h1>

	\uBE44\uC815\uC0C1\uC801\uC778 \uC811\uADFC\uC785\uB2C8\uB2E4. <a href="${"/"}">\uD648</a>\uC73C\uB85C \uB3CC\uC544\uAC00\uC2ED\uC2DC\uC624.
</main>`;
});
