# ch.ck 체·크

제공된 체크리스트 템플릿에 이용해, 자유롭게 체크리스트를 기록하고, 본인의 디바이스에 데이터를 저장할 수 있습니다.
데이터는 웹브라우저의 IndexedDB에 저장됩니다.

## 데모 실행 방법
1. 저장소를 클론한 뒤, npm install
1. /src/lib/templates/templates.template.ts를 자신이 원하는 대로 수정하고 /lib/templates/templates.ts로 이름 변경
1. npm run dev

## 버전 히스토리
0.9.0 2022.7.1
