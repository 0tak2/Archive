function g(t){return t.getFullYear()+"\uB144 "+(t.getMonth()+1)+"\uC6D4 "+t.getDate()+"\uC77C "+t.getHours()+":"+t.getMinutes()}export{g as t};
