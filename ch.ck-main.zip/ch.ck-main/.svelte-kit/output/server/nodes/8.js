import * as module from '../entries/pages/view/index.svelte.js';

export { module };
export const index = 8;
export const entry = 'pages/view/index.svelte-5e86b5ff.js';
export const js = ["pages/view/index.svelte-5e86b5ff.js","chunks/index-e5d6a794.js","chunks/navigation-fbae3e32.js","chunks/singletons-d1fb5791.js","chunks/dateHelper-8b7a18e0.js"];
export const css = ["assets/pages/view/index.svelte-d5cb5da8.css"];
