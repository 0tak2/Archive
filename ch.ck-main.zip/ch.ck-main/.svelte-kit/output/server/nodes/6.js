import * as module from '../entries/pages/new/index.svelte.js';

export { module };
export const index = 6;
export const entry = 'pages/new/index.svelte-b2a50e16.js';
export const js = ["pages/new/index.svelte-b2a50e16.js","chunks/index-e5d6a794.js","chunks/navigation-fbae3e32.js","chunks/singletons-d1fb5791.js"];
export const css = ["assets/pages/new/index.svelte-754e6476.css"];
