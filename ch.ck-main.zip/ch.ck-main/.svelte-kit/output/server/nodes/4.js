import * as module from '../entries/pages/mark/_id_.svelte.js';

export { module };
export const index = 4;
export const entry = 'pages/mark/_id_.svelte-e4bea301.js';
export const js = ["pages/mark/_id_.svelte-e4bea301.js","chunks/index-e5d6a794.js","chunks/stores-7301b8f1.js","chunks/navigation-fbae3e32.js","chunks/singletons-d1fb5791.js"];
export const css = ["assets/pages/mark/_id_.svelte-2902d071.css"];
