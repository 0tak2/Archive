import * as module from '../entries/pages/mark/index.svelte.js';

export { module };
export const index = 5;
export const entry = 'pages/mark/index.svelte-7fc48f3c.js';
export const js = ["pages/mark/index.svelte-7fc48f3c.js","chunks/index-e5d6a794.js"];
export const css = ["assets/pages/mark/index.svelte-7fac1fec.css"];
