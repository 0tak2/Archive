import * as module from '../entries/pages/index.svelte.js';

export { module };
export const index = 3;
export const entry = 'pages/index.svelte-f0bf689c.js';
export const js = ["pages/index.svelte-f0bf689c.js","chunks/index-e5d6a794.js","chunks/navigation-fbae3e32.js","chunks/singletons-d1fb5791.js","chunks/dateHelper-8b7a18e0.js"];
export const css = ["assets/pages/index.svelte-47c11e5c.css"];
