import * as module from '../entries/pages/view/_id_.svelte.js';

export { module };
export const index = 7;
export const entry = 'pages/view/_id_.svelte-77c9d053.js';
export const js = ["pages/view/_id_.svelte-77c9d053.js","chunks/index-e5d6a794.js","chunks/stores-7301b8f1.js","chunks/navigation-fbae3e32.js","chunks/singletons-d1fb5791.js"];
export const css = ["assets/pages/view/_id_.svelte-371c8ab1.css"];
