import * as module from '../entries/fallbacks/error.svelte.js';

export { module };
export const index = 1;
export const entry = 'error.svelte-c46e8a58.js';
export const js = ["error.svelte-c46e8a58.js","chunks/index-e5d6a794.js"];
export const css = [];
