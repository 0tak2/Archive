import * as module from '../entries/pages/help/index.svelte.js';

export { module };
export const index = 2;
export const entry = 'pages/help/index.svelte-26eedbb2.js';
export const js = ["pages/help/index.svelte-26eedbb2.js","chunks/index-e5d6a794.js"];
export const css = [];
