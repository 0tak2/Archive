import { c as create_ssr_component } from "../../../chunks/index-58de3ccc.js";
const Help = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${$$result.head += `${$$result.title = `<title>ch.ck: \uB3C4\uC6C0\uB9D0</title>`, ""}`, ""}

<div class="${"page_title"}">\uB3C4\uC6C0\uB9D0</div>
<main>\uCD94\uD6C4 \uCD94\uAC00
</main>`;
});
export { Help as default };
