import { c as create_ssr_component } from "../../../chunks/index-58de3ccc.js";
var index_svelte_svelte_type_style_lang = /* @__PURE__ */ (() => "main.svelte-mdfsuy{text-align:center;margin-bottom:15rem}h1.svelte-mdfsuy{width:100%}")();
const css = {
  code: "main.svelte-mdfsuy{text-align:center;margin-bottom:15rem}h1.svelte-mdfsuy{width:100%}",
  map: null
};
const Mark = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `${$$result.head += `${$$result.title = `<title>\uBE44\uC815\uC0C1\uC801\uC778 \uC811\uADFC</title>`, ""}`, ""}

<main class="${"svelte-mdfsuy"}"><h1 class="${"svelte-mdfsuy"}">\uBE44\uC815\uC0C1\uC801\uC778 \uC811\uADFC
	</h1>

	\uBE44\uC815\uC0C1\uC801\uC778 \uC811\uADFC\uC785\uB2C8\uB2E4. <a href="${"/"}">\uD648</a>\uC73C\uB85C \uB3CC\uC544\uAC00\uC2ED\uC2DC\uC624.
</main>`;
});
export { Mark as default };
