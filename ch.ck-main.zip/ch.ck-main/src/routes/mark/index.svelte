<svelte:head>
	<title>비정상적인 접근</title>
</svelte:head>

<main>
	<h1>
		비정상적인 접근
	</h1>

	비정상적인 접근입니다. <a href="/">홈</a>으로 돌아가십시오.
</main>

<style>
	main {
		text-align: center;
        margin-bottom: 15rem;
	}

	h1 {
		width: 100%;
	}
</style>
