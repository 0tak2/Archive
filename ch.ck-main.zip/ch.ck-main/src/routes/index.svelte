<script lang="ts">
	import Dashboard from '$lib/Dashboard.svelte'
</script>

<svelte:head>
	<title>ch.ck: 홈</title>
	<meta name="description" content="ch.ck 체크리스트 작성, 열람" />
</svelte:head>

<Dashboard/>
