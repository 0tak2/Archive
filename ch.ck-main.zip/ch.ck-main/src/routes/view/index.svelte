<script lang="ts">
    import ChcksTable from '$lib/ChcksTable.svelte'
</script>

<svelte:head>
	<title>ch.ck: 저장된 체크리스트 목록</title>
</svelte:head>

<div class="page_title">저장된 체크리스트 목록</div>

<div class="view">
    <ChcksTable />
</div>